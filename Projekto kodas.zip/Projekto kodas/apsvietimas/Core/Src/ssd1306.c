
#include "ssd1306.h"
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

extern I2C_HandleTypeDef hi2c1;

#define SSD1306_I2C_ADDR (0x3C << 1)

static uint8_t SSD1306_Buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];
static uint8_t currentX = 0;
static uint8_t currentY = 0;

static void SSD1306_WriteCommand(uint8_t command) {
    uint8_t data[2] = {0x00, command};
    HAL_I2C_Master_Transmit(&hi2c1, SSD1306_I2C_ADDR, data, 2, HAL_MAX_DELAY);
}

static void SSD1306_WriteData(uint8_t* data, size_t size) {
    uint8_t prefix = 0x40;
    HAL_I2C_Mem_Write(&hi2c1, SSD1306_I2C_ADDR, prefix, I2C_MEMADD_SIZE_8BIT, data, size, HAL_MAX_DELAY);
}

void SSD1306_Init(void) {
    HAL_Delay(100);

    SSD1306_WriteCommand(0xAE);
    SSD1306_WriteCommand(0x20); // Set Memory Addressing Mode
    SSD1306_WriteCommand(0x10); // Page addressing mode
    SSD1306_WriteCommand(0xB0); // Set Page Start Address for Page Addressing Mode
    SSD1306_WriteCommand(0xC8);
    SSD1306_WriteCommand(0x00); // Set low column address
    SSD1306_WriteCommand(0x10); // Set high column address
    SSD1306_WriteCommand(0x40); // Set start line address
    SSD1306_WriteCommand(0x81); // Set contrast control register
    SSD1306_WriteCommand(0xFF);
    SSD1306_WriteCommand(0xA1); // Set segment re-map 0 to 127
    SSD1306_WriteCommand(0xA6); // Set normal display
    SSD1306_WriteCommand(0xA8); // Set multiplex ratio(1 to 64)
    SSD1306_WriteCommand(0x3F);
    SSD1306_WriteCommand(0xA4); // Output follows RAM content
    SSD1306_WriteCommand(0xD3); // Set display offset
    SSD1306_WriteCommand(0x00); // No offset
    SSD1306_WriteCommand(0xD5); // Set display clock divide ratio
    SSD1306_WriteCommand(0xF0); // Set divide ratio
    SSD1306_WriteCommand(0xD9); // Set pre-charge period
    SSD1306_WriteCommand(0x22);
    SSD1306_WriteCommand(0xDA); // Set com pins hardware configuration
    SSD1306_WriteCommand(0x12);
    SSD1306_WriteCommand(0xDB); // Set vcomh
    SSD1306_WriteCommand(0x20); // 0.77xVcc
    SSD1306_WriteCommand(0x8D); // Charge Pump
    SSD1306_WriteCommand(0x14);
    SSD1306_WriteCommand(0xAF); // Display ON

    SSD1306_Clear();
    SSD1306_UpdateScreen();
}

void SSD1306_UpdateScreen(void) {
    for (uint8_t page = 0; page < 8; page++) {
        SSD1306_WriteCommand(0xB0 + page);
        SSD1306_WriteCommand(0x00);
        SSD1306_WriteCommand(0x10);
        SSD1306_WriteData(&SSD1306_Buffer[SSD1306_WIDTH * page], SSD1306_WIDTH);
    }
}

void SSD1306_Clear(void) {
    memset(SSD1306_Buffer, 0x00, sizeof(SSD1306_Buffer));
    currentX = 0;
    currentY = 0;
}

void SSD1306_GotoXY(uint8_t x, uint8_t y) {
    currentX = x;
    currentY = y;
}

static const uint8_t Font5x7[][5] = {
    // ASCII font table 32-127 (space to ~)
#include "font5x7.inc"
};

void SSD1306_Putc(char ch) {
    if (ch < 32 || ch > 126) ch = '?';
    for (int i = 0; i < 5; i++) {
        SSD1306_Buffer[currentX + (currentY / 8) * SSD1306_WIDTH] = Font5x7[ch - 32][i];
        currentX++;
    }
    SSD1306_Buffer[currentX + (currentY / 8) * SSD1306_WIDTH] = 0x00;
    currentX++;
}

void SSD1306_Printf(const char* fmt, ...) {
    char buffer[64];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    for (char* p = buffer; *p; p++) {
        if (*p == '\n') {
            currentY += 8;
            currentX = 0;
        } else {
            SSD1306_Putc(*p);
        }
    }
}
