
#ifndef __SSD1306_H__
#define __SSD1306_H__

#include "stm32l0xx_hal.h"
#include <stdint.h>

#define SSD1306_WIDTH 128
#define SSD1306_HEIGHT 64

void SSD1306_Init(void);
void SSD1306_UpdateScreen(void);
void SSD1306_Clear(void);
void SSD1306_GotoXY(uint8_t x, uint8_t y);
void SSD1306_Putc(char ch);
void SSD1306_Printf(const char* fmt, ...);

#endif // __SSD1306_H__
