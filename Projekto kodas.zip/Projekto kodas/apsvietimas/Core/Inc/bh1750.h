
#ifndef __BH1750_H__
#define __BH1750_H__

#include "stm32l0xx_hal.h"

typedef struct {
    I2C_HandleTypeDef* i2c;
    uint8_t addr;
} BH1750_Device;

void bh1750_begin(BH1750_Device* dev);
float bh1750_read_light(BH1750_Device* dev);

#endif // __BH1750_H__
