
#include "bh1750.h"
#include "stm32l0xx_hal.h"
#include "main.h"

#define BH1750_POWER_ON 0x01
#define BH1750_RESET    0x07
#define BH1750_CONTINUOUS_HIGH_RES_MODE 0x10

void bh1750_begin(BH1750_Device* dev)
{
    uint8_t cmd;

    // Power on
    cmd = BH1750_POWER_ON;
    HAL_I2C_Master_Transmit(dev->i2c, dev->addr << 1, &cmd, 1, HAL_MAX_DELAY);

    // Reset
    cmd = BH1750_RESET;
    HAL_I2C_Master_Transmit(dev->i2c, dev->addr << 1, &cmd, 1, HAL_MAX_DELAY);

    // Set continuous high res mode
    cmd = BH1750_CONTINUOUS_HIGH_RES_MODE;
    HAL_I2C_Master_Transmit(dev->i2c, dev->addr << 1, &cmd, 1, HAL_MAX_DELAY);
}

float bh1750_read_light(BH1750_Device* dev)
{
    uint8_t data[2];
    if (HAL_I2C_Master_Receive(dev->i2c, dev->addr << 1, data, 2, HAL_MAX_DELAY) != HAL_OK)
        return -1.0f;

    uint16_t raw = (data[0] << 8) | data[1];
    return raw / 1.2f; // Convert to lux
}
